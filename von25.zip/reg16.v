`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    13:13:10 01/28/2022 
// Design Name: 
// Module Name:    reg16 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module reg16(
	 input clk,
    input Load,
    input Rst,
	 input FGI,
	 input grst,
	 input FGO,
	 input [7:0] In,
	 output [7:0] outreg,
	 input En,
	 input [11:0] Data,
    output [11:0] out
    );
reg [11:0] R;
reg [7:0] RR;
always@ (posedge clk)
	begin 
		if(Rst||grst)
			R <=0;
		else if(Load)
			R <= Data;
		else if (En)
			R <= R+1;
		else if(FGI)
			R <={4'b0000,In};
		else if(FGO)
			RR <= R[7:0];
		else
			R<=0;
	end
assign out=R;
assign outreg=RR;

endmodule
