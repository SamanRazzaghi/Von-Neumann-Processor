`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    16:24:41 01/29/2022 
// Design Name: 
// Module Name:    S 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module S(
	 input clk,
    input Rst,
	 input grst,
    output out
    );
reg R;
always@ (posedge clk)
	begin 
		if(Rst||grst)
			R <=0;
		else
			R <=1'b1;
	end
assign out=R;

endmodule
