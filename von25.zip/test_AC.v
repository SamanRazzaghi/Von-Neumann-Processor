`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   18:56:23 01/29/2022
// Design Name:   reg16
// Module Name:   C:/Users/Saman/Documents/ISE/CPU_amir/von25/test_AC.v
// Project Name:  von25
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: reg16
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module test_AC;

	// Inputs
	reg clk;
	reg Load;
	reg Rst;
	reg FGI;
	reg grst;
	reg FGO;
	reg [7:0] In;
	reg En;
	reg [11:0] Data;

	// Outputs
	wire [7:0] outreg;
	wire [11:0] out;

	// Instantiate the Unit Under Test (UUT)
	reg16 uut (
		.clk(clk), 
		.Load(Load), 
		.Rst(Rst), 
		.FGI(FGI), 
		.grst(grst), 
		.FGO(FGO), 
		.In(In), 
		.outreg(outreg), 
		.En(En), 
		.Data(Data), 
		.out(out)
	);
   always
	begin
	clk=0;
	#5;
	clk=1;
	#5;
	end
	initial begin
		// Initialize Inputs
		Load = 1;
		Rst = 0;
		FGI = 0;
		grst = 0;
		FGO = 0;
		In = 0;
		En = 0;
		Data = 5;

		// Wait 100 ns for global reset to finish
		#10;
		Load = 0;
		Rst = 0;
		FGI = 0;
		grst = 0;
		FGO = 1;
		In = 0;
		En = 0;
		Data = 5;
		#10;
		Load = 0;
		Rst = 0;
		FGI = 1;
		grst = 0;
		FGO = 0;
		In = 10;
		En = 0;
		Data = 0;
        
		// Add stimulus here

	end
      
endmodule

