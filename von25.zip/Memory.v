`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    13:56:51 01/28/2022 
// Design Name: 
// Module Name:    Memory 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Memory(
	input clk,
	input [11:0]ADR,
	input WE,
	input [15:0]WD,
	output [15:0]RD
    );
reg [15:0] RAM [0:127];
integer i;
initial
	begin	   
		RAM[0]=16'h0005;
		RAM[1]=16'h2006;
		RAM[2]=16'h1008;
		RAM[3]=16'h4003;
		RAM[4]=16'h0000;
		RAM[5]=16'h0007;
		RAM[6]=16'h0004;
		RAM[7]=16'h0000;
		RAM[8]=16'h0000;
		for(i=9;i<128;i=i+1)
			RAM[i]=0;
	end


assign RD=RAM[ADR];
always@(posedge clk)
begin
	if(WE)
		RAM[ADR]<=WD;
end  
endmodule
